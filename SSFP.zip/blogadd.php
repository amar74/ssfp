<?php
error_reporting(1);

$servername = "localhost";
$username = "root";
$password = "";

$dbname = "ssfp";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error){
  die("Connection Failed: ".$conn->connect_error);
}
if (isset($_REQUEST['blog_post'])){
  $title = mysqli_real_escape_string($conn, $_POST['title']);
  $videolink = mysqli_real_escape_string($conn, $_POST['videolink']);
  $date1 = mysqli_real_escape_string($conn, $_POST['date1']);
  $description = mysqli_real_escape_string($conn, $_POST['description']);

$target_dir = "blog/";
$target_file = $target_dir . date("Ymd") . rand(111111,99999) . basename($_FILES["file"]["name"]);
// echo $target_file;
//return;
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["blog_post"])) {
    $check = getimagesize($_FILES["file"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["file"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
      $ssfpi = "INSERT INTO blog (title, file, videolink, date1, description)
      VALUES('$title', '$target_file', '$videolink', '$date1', '$description' )";
        mysqli_query($conn, $ssfpi);
        echo "The file ". basename( $_FILES["file"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Star Studio Film Production | Admin</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/font-awesome.min.css" rel="stylesheet">

    <link href="css/animate.min.css" rel="stylesheet">

    <link href="css/owl.css" rel="stylesheet">

    <link href="css/jarallax.css" rel="stylesheet">

    <link href="css/pogo-slider.css" rel="stylesheet">

    <link href="css/style.css" rel="stylesheet">

    <link href="css/responsive.css" rel="stylesheet">

    <style>
    #about_sh {
      border: 0.5px;
      box-shadow: 2px 3px #b2adad4f;
    }

    input[type=text], select, textarea{
      width: 100%;
      padding: 12px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      resize: vertical;
    }

    /* Style the label to display next to the inputs */
    label {
      padding: 12px 12px 12px 0;
      display: inline-block;
    }

    /* Style the submit button */
    input[type=submit] {
      background-color: #4CAF50;
      color: white;
      padding: 12px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      float: right;
    }

    .col-25 {
      float: left;
      width: 25%;
      margin-top: 6px;
    }

    /* Floating column for inputs: 75% width */
    .col-75 {
      float: left;
      width: 75%;
      margin-top: 6px;
    }

    /* Clear floats after the columns */
    .row:after {
      content: "";
      display: table;
      clear: both;
    }

    @media screen and (max-width: 600px) {
      .col-25, .col-75, input[type=submit] {
        width: 100%;
        margin-top: 0;
      }
    }
</style>

</head>

<body>

    <header class="header-area" style="position: absolute;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-9 col-lg-8 col-md-12">
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <a class="navbar-brand" href="index.php">
                            <img class="logo-1" src="Img/logo.png" style="height: 35px; width: 65px;" class="img-fluid">
                            <img class="logo-2" src="Img/logo.png" style="height: 35px; width: 65px;" class="img-fluid">
                        </a>
                    </nav>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-12">
                    <div class="header-social-col">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        </ul>
                        <div class="header-btn">
                            <a class="#" href="https://www.youtube.com/channel/UC9--8XOvnrwgwkpeL9QBKqg" style="border-radius: 20px;">Logout</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Page Name Start -->
    <section class="page-name-area page-name-two-area background-image overlay-white" data-src="Img/3.jpg">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-name-col text-center">
                        <h2>Star Studio Film Production</h2>
                        <h6>We are Start Studio film Production, Short film, Web series, Portfolio &amp; Ads maker with a real passion.</h6>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="" style="margin-top: 25px; background-color: #e9ecec52">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="my-title">
                        <h2>Post Blog</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-12" style="margin-top: 20px; margin-bottom: 20px;">
                <div class="row">
                    <div class="col-md-6" id="about_sh" style="background-color: white; margin-right: 10px; margin-left: : 10px; margin-bottom: 10px;">
                        <form method="post" action="#" style="margin-bottom: 10px; margin-top: 20px; margin-right: 20px; margin-left: 15px;" enctype="multipart/form-data">
                                    <div class="row">
                                      <div class="col-25">
                                        <label for="title">Blog Title</label>
                                      </div>
                                      <div class="col-75">
                                        <input type="text" id="title" name="title" placeholder="Blog Title..">
                                      </div>
                                    </div>
                                    <div class="row">
                                      <div class="col-25">
                                        <label for="file">Upload File</label>
                                      </div>
                                      <div class="col-75">
                                        <input type="file" id="file" name="file" placeholder="Upload file...">
                                      </div>
                                    </div>
                                    <div class="row">
                                      <div class="col-25">
                                        <label for="date1">Video Link</label>
                                      </div>
                                      <div class="col-75">
                                        <input type="text" id="videolink" name="videolink" placeholder="Video URL">
                                      </div>
                                    </div>
                                    <div class="row">
                                      <div class="col-25">
                                        <label for="date1">Date</label>
                                      </div>
                                      <div class="col-75">
                                        <input type="date" id="date1" name="date1" placeholder="Upload date...">
                                      </div>
                                    </div>
                                    <div class="row">
                                      <div class="col-25">
                                        <label for="description">Description</label>
                                      </div>
                                      <div class="col-75">
                                        <textarea id="description" name="description" placeholder="Write something.." style="height:150px"></textarea>
                                      </div>
                                    </div>
                                    <div class="row" style="margin-bottom: 20px; float: right;">
                                      <input type="submit" value="Post" id="blog_post" name="blog_post">
                                    </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="service-area" style="margin-top: 25px;">
        <div class="container">
            
        </div>
    </section>

    <footer class="footer-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-5">
                    <div class="widget footer-col logo-col">
                        <img src="Img/logo.png" style="height: 35px; width: 70px;" >
                        <p>This is Star Studio films Production. We makes Short Films,  Web series, Music Albums, Portfolio, Photography, Music, Music Composing with Fresh Content. Our production is established at Ghaziabad in 2017 by Shivansh Saxena. He is the owner & Founder of This Production. Production always provide you best work and it's a great Opportunity for New Talent.</p>
                        <ul>
                            <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-5 col-md-4">
                    <div class="widget footer-col subscribe-col">
                        <h4>Get the latest information about Offers & Promotion</h4>
                        <form action="#">
                            <input type="email" class="form-control" placeholder="Email">
                            <button class="btn btn-primary my-btn" type="submit">Subscribe</button>
                        </form>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3">
                    <div class="widget footer-col footer-menu">
                        <h5>Quick link</h5>
                        <ul>
                            <li><a href="#">Home</a></li>
                            <li><a href="#">Portfolio</a></li>
                            <li><a href="#">Web Series</a></li>
                            <li><a href="#">Ads Maker</a></li>
                            <li><a href="#">Contact</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <br />
            <div class="row">
                <div class="col-lg-12">
                    <p class="copy-right">© 2019 Star Studio Film Production, Developed <span>by Zetatron Solutions Pvt. Ltd. </span></p>
                </div>
            </div>
        </div>
    </footer>

    <script src="js/jquery.min.js"></script>

    <script src="js/popper.min.js"></script>

    <script src="js/bootstrap.min.js"></script>

    <script src="js/jarallax.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/froogaloop2.min.js"></script>
    <script src="js/html5lightbox.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>
    <script src="js/jquery.pogo-slider.js"></script>

    <script src="js/custom.js"></script>

</body>

</html>