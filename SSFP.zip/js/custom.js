﻿(function($) {

	"use strict";



    // Header Fixed
    $(window).scroll(function(){
      var sticky = $('.sticky'),
          scroll = $(window).scrollTop();

      if (scroll >= 50) sticky.addClass('fixed');
      else sticky.removeClass('fixed');
    });



    // Menu Script 
    jQuery(document).ready(function(){
        // fadeIn() for smoth loading
        jQuery(".menu-container").fadeIn();
        jQuery(".menu-container .manu ul li:has(ul)").children("ul").not("ul li ul li ul").addClass("have_dropdown");
        
        //Checks if drodown menu's li elements have anothere level (ul), if not the dropdown is shown as regular dropdown, not a mega menu
        jQuery(".menu-container .manu ul li ul:has(li ul li)").removeClass("have_dropdown").addClass("have_dropdown_n_style");
        
         //Checks if li has sub (ul) and adds class for toggle icon 
        jQuery(".menu-container .manu ul li:has('ul')").children("a").not(".manu ul li ul li a").append("<span class='drop_down_icon fas fa-bars'></span>");
        
        
        if (jQuery(window).width() < 991) {
            //If width is less or equal to 943px dropdowns are displayed on click
            jQuery(".menu-container .manu ul li a").not("ul li ul li a").click(function(){
                jQuery(this).removeAttr("href");
            });
             jQuery(".menu-container .manu ul li").click(function(){
                jQuery(this).children(".have_dropdown").not(".have_dropdown li a").slideToggle(100);
            });

            jQuery(".menu-container .manu ul li").click(function(){
                jQuery(this).children(".have_dropdown_n_style").not(".have_dropdown_n_style li a").slideToggle(100);
            }); 
            
            //================================================================
            
            jQuery(".nav_menu_toggler_icon").click(function(){
                jQuery(".menu-container .manu").slideToggle();
            });
            
         }else{
            
            //If width is more than 756px dropdowns are displayed on hover
             
            jQuery(".menu-container .manu ul li").hover(function(){
                jQuery(this).children(".have_dropdown").not(".have_dropdown li a").slideDown(200);
            },function(){
                jQuery(this).children(".have_dropdown").not(".have_dropdown li a").slideUp(100);
            });

            jQuery(".menu-container .manu ul li").hover(function(){
                jQuery(this).children(".have_dropdown_n_style").not(".have_dropdown_n_style li a").slideDown(100);
            },function(){
                jQuery(this).children(".have_dropdown_n_style").not(".have_dropdown_n_style li a").slideUp(100);
            }); 
         }
    });



    //Bootstrap Carousel
    $('.carousel').carousel({
        pause: "false"
    });



    // Pogo Slider
    if($('#pogo-slider').length > 0){
            $('#pogo-slider').pogoSlider({
            autoplay: true,
            generateButtons: false,
            autoplayTimeout: 5000,
            displayProgess: true,
            targetWidth: 1920,
            // targetHeight: 500,
            responsive: true,
            pauseOnHover: false,
        }).data('plugin_pogoSlider');
    }


    // testimonial-carousel
    if($('.testimonial-carousel').length){
        $('.testimonial-carousel').owlCarousel({
            loop: true,
            margin: 30,
            dots: true,
            nav: false,
            autoplayHoverPause: false,
            autoplay: true,
            autoplayTimeout: 4000,
            smartSpeed: 800,
            center: false,
            // navText: [
            //   '<i class="fa fa-long-arrow-down"></i>',
            //   '<i class="fa fa-long-arrow-up"></i>'
            // ],
            responsive: {
                0: {
                    items: 1,
                    center: false
                },
                480:{
                    items:1,
                    center: false
                },
                600: {
                    items: 1,
                    center: false
                },
                768: {
                    items: 2
                },
                992: {
                    items: 2
                },
                1200: {
                    items: 2
                }
            }
        })
    }


    // project-carousel
    if($('.project-slider').length){
        $('.project-slider').owlCarousel({
            loop: true,
            margin: 0,
            dots: false,
            nav: true,
            autoplayHoverPause: false,
            autoplay: true,
            autoplayTimeout: 4000,
            smartSpeed: 800,
            center: false,
            navText: [
              '<i class="fa fa-arrow-circle-o-left"></i>',
              '<i class="fa fa-arrow-circle-o-right"></i>'
            ],
            responsive: {
                0: {
                    items: 1,
                    center: false
                },
                480:{
                    items:1,
                    center: false
                },
                600: {
                    items: 1,
                    center: false
                },
                768: {
                    items: 1
                },
                992: {
                    items: 1
                },
                1200: {
                    items: 1
                }
            }
        })
    }


    // Isotope Script
    $(window).on('load', function() {
        function sortingGallery() {
            if ($(".my-gallery .gallery-nav").length) {
                var $container = $('.gallery-container');
                $container.isotope({
                    filter:'*',
                    animationOptions: {
                        duration: 750,
                        easing: 'linear',
                        queue: false,
                    }
                });

                $(".gallery-nav li a").on("click", function() {
                    $('.gallery-nav li .active').removeClass('active');
                    $(this).addClass('active');
                    var selector = $(this).attr('data-filter');
                    $container.isotope({
                        filter:selector,
                        animationOptions: {
                            duration: 750,
                            easing: 'linear',
                            queue: false,
                        }
                    });
                    return false;
                });
            }
        }
        sortingGallery();
    }); 
    $('.gallery-container').isotope({
      itemSelector: '.item',
      masonry: {
        gutter: 30
      }
    });

    $(window).on('load', function() {
        function sortingGallery() {
            if ($(".my-gallery .gallery-nav").length) {
                var $container = $('.gallery-container-nospace');
                $container.isotope({
                    filter:'*',
                    animationOptions: {
                        duration: 750,
                        easing: 'linear',
                        queue: false,
                    }
                });

                $(".gallery-nav li a").on("click", function() {
                    $('.gallery-nav li .active').removeClass('active');
                    $(this).addClass('active');
                    var selector = $(this).attr('data-filter');
                    $container.isotope({
                        filter:selector,
                        animationOptions: {
                            duration: 750,
                            easing: 'linear',
                            queue: false,
                        }
                    });
                    return false;
                });
            }
        }
        sortingGallery();
    }); 
    $('.gallery-container-nospace').isotope({
      itemSelector: '.item',
      masonry: {
        gutter: 0
      }
    });






    // Background Image Call Script
    if ($('.background-image').length > 0) {
        $('.background-image').each(function () {
            var src = $(this).attr('data-src');
            $(this).css({
                'background-image': 'url(' + src + ')'
            });
        });
    }



    // Parallax background
    $('.parallax').jarallax({
        speed: 0.5
    });



})(window.jQuery);