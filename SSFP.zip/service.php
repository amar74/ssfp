<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">

    <title>Star Studio Film Production | Services</title>
    <link href="https://fonts.googleapis.com/css?family=Livvic:400,500,600,700&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli:400,600&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans:300,400,600&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=ZCOOL+XiaoWei&amp;display=swap" rel="stylesheet">

    <link href="css/bootstrap.min.css" rel="stylesheet">

    
    <link href="css/font-awesome.min.css" rel="stylesheet">

    <link href="css/animate.min.css" rel="stylesheet">

    <link href="css/owl.css" rel="stylesheet">

    <link href="css/jarallax.css" rel="stylesheet">

    <link href="css/pogo-slider.css" rel="stylesheet">

    <link href="css/style.css" rel="stylesheet">

    <link href="css/responsive.css" rel="stylesheet">

    <style>
    #about_sh {
      border: 0.5px;
      box-shadow: 2px 3px #b2adad4f;
    }
    </style>

</head>

<body>

    <header class="header-area sticky">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-9 col-lg-8 col-md-12">
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <a class="navbar-brand" href="index.php">
                            <img class="logo-1" src="Img/logo.png" style="height: 35px; width: 65px;" class="img-fluid">
                            <img class="logo-2" src="Img/logo.png" style="height: 35px; width: 65px;" class="img-fluid">
                        </a>
                        <div class="menu-container clearfix">
                            <button class="nav_menu_toggler_icon"><span class="fa fa-bars"></span></button>
                            <nav class="manu clearfix">
                                <ul>
                                  <li><a href="index.php">Home</a></li>
                                  <li class="current-menu-item"><a href="service.php">Services</a></li>
                                  <li><a href="about.php">Portfolio</a></li>
                                  <li><a href="blog.php">Blog</a></li>
                                  <li><a href="gallery.php">Gallery</a></li>
                                  <li><a href="contact.php">Contact</a></li>
                                </ul>
                            </nav>
                        </div>
                    </nav>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-12">
                    <div class="header-social-col">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        </ul>
                        <div class="header-btn">
                            <a class="#" href="https://www.youtube.com/channel/UC9--8XOvnrwgwkpeL9QBKqg" style="border-radius: 20px;">YouTube</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Page Name Start -->
    <section class="page-name-area page-name-two-area background-image overlay-white" data-src="Img/3.jpg">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-name-col text-center">
                        <h6>Star Studio Film Production</h6>
                        <h2>Our Services</h2>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="" style="margin-top: 25px; background-color: #e9ecec52">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="my-title">
                        <h2>Start Studio film Production</h2>
                        <p>We are Start Studio film Production, Short film, Web series, Portfolio &amp; Ads maker with a real passion.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="row">
                    <div id="about_sh" style="width: 350px; background-color: white; margin-right: 10px; margin-left: : 10px; margin-bottom: 10px;">
                        <div>
                            <center>
                                <h4 style="margin-top: 20px; margin-bottom: 20px;">Short films Production</h4>

                                <img src="Img/1.jpg" style="width: 300px; height: 250px;"> <br />
                                <br />
                                <p> We are Start Studio film Production, Short film, Web series, Portfolio &amp; Ads maker with a real passion.</p>
                                <button class="btn btn-primary my-btn" style="border-radius: 15px; margin-bottom: 20px;"><a href="https://www.youtube.com/channel/UC9--8XOvnrwgwkpeL9QBKqg">Subscribe</a></button>
                            </center>
                        </div>
                    </div>
                    <div id="about_sh" style="width: 350px; background-color: white; margin-right: 10px; margin-left: : 10px; margin-bottom: 10px;">
                        <div>
                            <center>
                                <h4 style="margin-top: 20px; margin-bottom: 20px;">Web Series Production</h4>

                                <img src="Img/2.jpg" style="width: 300px; height: 250px;"> <br />
                                <br />
                                <p> We are Start Studio film Production, Short film, Web series, Portfolio &amp; Ads maker with a real passion.</p>
                                <button class="btn btn-primary my-btn" style="border-radius: 15px; margin-bottom: 20px;"><a href="https://www.youtube.com/channel/UC9--8XOvnrwgwkpeL9QBKqg">Subscribe</a></button>
                            </center>
                        </div>
                    </div>
                    <div id="about_sh" style="width: 350px; background-color: white; margin-right: 10px; margin-left: : 10px; margin-bottom: 10px;">
                        <div>
                            <center>
                                <h4 style="margin-top: 20px; margin-bottom: 20px;">Portfolio</h4>

                                <img src="Img/3.jpg" style="width: 300px; height: 250px;"> <br />
                                <br />
                                <p> We are Start Studio film Production, Short film, Web series, Portfolio &amp; Ads maker with a real passion.</p>
                                <button class="btn btn-primary my-btn" style="border-radius: 15px; margin-bottom: 20px;"><a href="https://www.youtube.com/channel/UC9--8XOvnrwgwkpeL9QBKqg">Subscribe</a></button>
                            </center>
                        </div>
                    </div>
                    <div id="about_sh" style="width: 350px; background-color: white; margin-right: 10px; margin-left: : 10px; margin-bottom: 10px;">
                        <div>
                            <center>
                                <h4 style="margin-top: 20px; margin-bottom: 20px;">Photography</h4>

                                <img src="Img/7.jpg" style="width: 300px; height: 250px;"> <br />
                                <br />
                                <p> We are Start Studio film Production, Short film, Web series, Portfolio &amp; Ads maker with a real passion.</p>
                                <button class="btn btn-primary my-btn" style="border-radius: 15px; margin-bottom: 20px;"><a href="https://www.youtube.com/channel/UC9--8XOvnrwgwkpeL9QBKqg">Subscribe</a></button>
                            </center>
                        </div>
                    </div>
                    <div id="about_sh" style="width: 350px; background-color: white; margin-right: 10px; margin-left: : 10px; margin-bottom: 10px;">
                        <div>
                            <center>
                                <h4 style="margin-top: 20px; margin-bottom: 20px;">Video Editing</h4>

                                <img src="Img/8.jpg" style="width: 300px; height: 250px;"> <br />
                                <br />
                                <p> We are Start Studio film Production, Short film, Web series, Portfolio &amp; Ads maker with a real passion.</p>
                                <button class="btn btn-primary my-btn" style="border-radius: 15px; margin-bottom: 20px;"><a href="https://www.youtube.com/channel/UC9--8XOvnrwgwkpeL9QBKqg">Subscribe</a></button>
                            </center>
                        </div>
                    </div>
                    <div id="about_sh" style="width: 350px; background-color: white; margin-right: 10px; margin-left: : 10px; margin-bottom: 10px;">
                        <div>
                            <center>
                                <h4 style="margin-top: 20px; margin-bottom: 20px;">Sound Recording</h4>

                                <img src="Img/9.jpg" style="width: 300px; height: 250px;"> <br />
                                <br />
                                <p> We are Start Studio film Production, Short film, Web series, Portfolio &amp; Ads maker with a real passion.</p>
                                <button class="btn btn-primary my-btn" style="border-radius: 15px; margin-bottom: 20px;"><a href="https://www.youtube.com/channel/UC9--8XOvnrwgwkpeL9QBKqg">Subscribe</a></button>
                            </center>
                        </div>
                    </div>
                    <div id="about_sh" style="width: 350px; background-color: white; margin-right: 10px; margin-left: : 10px; margin-bottom: 10px;">
                        <div>
                            <center>
                                <h4 style="margin-top: 20px; margin-bottom: 20px;">Music Composing</h4>

                                <img src="Img/10.jpg" style="width: 300px; height: 250px;"> <br />
                                <br />
                                <p> We are Start Studio film Production, Short film, Web series, Portfolio &amp; Ads maker with a real passion.</p>
                                <button class="btn btn-primary my-btn" style="border-radius: 15px; margin-bottom: 20px;"><a href="https://www.youtube.com/channel/UC9--8XOvnrwgwkpeL9QBKqg">Subscribe</a></button>
                            </center>
                        </div>
                    </div>
                    <div id="about_sh" style="width: 350px; background-color: white; margin-right: 10px; margin-left: : 10px; margin-bottom: 10px;">
                        <div>
                            <center>
                                <h4 style="margin-top: 20px; margin-bottom: 20px;">Ads Maker</h4>

                                <img src="Img/11.jpg" style="width: 300px; height: 250px;"> <br />
                                <br />
                                <p> We are Start Studio film Production, Short film, Web series, Portfolio &amp; Ads maker with a real passion.</p>
                                <button class="btn btn-primary my-btn" style="border-radius: 15px; margin-bottom: 20px;"><a href="https://www.youtube.com/channel/UC9--8XOvnrwgwkpeL9QBKqg">Subscribe</a></button>
                            </center>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="service-area" style="margin-top: 25px;">
        <div class="container">
            
        </div>
    </section>
    
    <section class="contact-separator-area parallax overlay-black background-image" data-src="Img/52.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="contact-info-box">
                        <h2>Contact us</h2>
                        <h5>Hours</h5>
                        <p>Monday to Saturday: 9:00 AM-7:00 PM</p>
                        <p>Sunday: 10:30am-3pm  Closed​</p>
                        <h5>Contact us</h5>
                        <p>adress: </p>
                        <p>Tel:  +91-1234567890</p>
                        <p>Email : shivansh@starstudiofilmproduction.com</p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="contact-separator-col">
                        <h2>Welcome to the Star Studio Film Production</h2>
                        <p>Dummy Data </p>
                        <a class="btn btn-primary my-btn" href="contact.php" role="button">Take services</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer class="footer-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-5">
                    <div class="widget footer-col logo-col">
                        <img src="Img/logo.png" style="height: 35px; width: 70px;" >
                        <p>This is Star Studio films Production. We makes Short Films,  Web series, Music Albums, Portfolio, Photography, Music, Music Composing with Fresh Content. Our production is established at Ghaziabad in 2017 by Shivansh Saxena. He is the owner & Founder of This Production. Production always provide you best work and it's a great Opportunity for New Talent.</p>
                        <ul>
                            <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-5 col-md-4">
                    <div class="widget footer-col subscribe-col">
                        <h4>Get the latest information about Offers & Promotion</h4>
                        <form action="#">
                            <input type="email" class="form-control" placeholder="Email">
                            <button class="btn btn-primary my-btn" type="submit">Subscribe</button>
                        </form>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3">
                    <div class="widget footer-col footer-menu">
                        <h5>Quick link</h5>
                        <ul>
                            <li><a href="#">Home</a></li>
                            <li><a href="#">Portfolio</a></li>
                            <li><a href="#">Web Series</a></li>
                            <li><a href="#">Ads Maker</a></li>
                            <li><a href="#">Contact</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <br />
            <div class="row">
                <div class="col-lg-12">
                    <p class="copy-right">© 2019 Star Studio Film Production, Developed <span>by Zetatron Solutions Pvt. Ltd. </span></p>
                </div>
            </div>
        </div>
    </footer>

    <script src="js/jquery.min.js"></script>

    <script src="js/popper.min.js"></script>

    <script src="js/bootstrap.min.js"></script>

    <script src="js/jarallax.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/froogaloop2.min.js"></script>
    <script src="js/html5lightbox.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>
    <script src="js/jquery.pogo-slider.js"></script>

    <script src="js/custom.js"></script>

</body>

</html>